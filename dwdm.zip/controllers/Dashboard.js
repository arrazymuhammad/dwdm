module.exports = {
	index(req, res) {
		res.render("dashboard/index")
	}
}
