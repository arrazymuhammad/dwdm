var MONTH = ['', "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
 	
var config = {
	type: 'line',
	options: {
        responsive: true,
        scales: {yAxes: [{ ticks: {beginAtZero: true}}]},
	}
};
